USE  projetoIntegrador;

SELECT * FROM Usuario;
SELECT * FROM cargo;
SELECT * FROM cliente;
SELECT * FROM telefoneCliente;
SELECT * FROM funcionario;
SELECT * FROM telefoneFuncionario;
SELECT * FROM itemVenda;
SELECT * FROM esquadria;
SELECT * FROM pagamento;
SELECT * FROM venda;
SELECT * FROM distribuidorAluminio;
SELECT * FROM telefoneDistribuidor;

 